#!/bin/bash

uv run flake8 DSP2_client tests main.py
PYTHONPATH=. uv run pytest
uv run main.py
