#!/bin/bash

curl -LsSf https://astral.sh/uv/install.sh | sh
uv run flake8 DSP2_client tests main.py
PYTHONPATH=. uv run pytest
uv run main.py
