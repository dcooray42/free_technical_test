import httpx
from models import ClientConfig, OAuth, ErrorResponse
from typing import Union
from pydantic import HttpUrl


class Client:
    def __init__(self, config: ClientConfig):
        self.base_url = config.base_url.rstrip("/")
        self.username = config.username
        self.password = config.password
        self.auth: Union[OAuth, ErrorResponse, None] = None

    def authentication(self, url: HttpUrl) -> int:
        response = httpx.post(
            url + "/oauth/token",
            self.username,
            self.password
        )
        status_code = response.status_code
        if status_code == 200:
            self.auth = OAuth(**response.json())
            return status_code
        else:
            self.auth = ErrorResponse(response.json())
            return status_code
