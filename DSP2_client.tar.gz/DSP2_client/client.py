import httpx
from DSP2_client.models import (
    Account,
    Accounts,
    Balances,
    ClientConfig,
    ErrorResponse,
    Identity,
    Token,
    Transactions
)
from typing import Union, Dict


class Client:
    def __init__(self, config: ClientConfig):
        self.base_url = str(config.base_url).rstrip("/")
        self.username = config.username
        self.password = config.password

    def _get_request(
            self,
            url: str,
            token: Token,
            params: Dict = None
    ) -> httpx.Response:
        return httpx.get(
            url,
            headers={
                "Authorization": f"Bearer {token.access_token}",
                "Accept": "application/json"
            },
            params=params
        )

    def authentication(self) -> Union[Token, ErrorResponse]:
        """Return the token of a valid user"""
        response = httpx.post(
            f"{self.base_url}/oauth/token",
            data={
                "username": self.username,
                "password": self.password,
                "scope": "stet"
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        if response.status_code == 200:
            return Token(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_identity(self, token: Token) -> Union[Identity, ErrorResponse]:
        """Return the identity of the user"""
        response = self._get_request(
            f"{self.base_url}/stet/identity",
            token
        )
        if response.status_code == 200:
            return Identity(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_accounts(self, token: Token) -> Union[Accounts, ErrorResponse]:
        """Return all the accounts linked to a user"""
        response = self._get_request(
            f"{self.base_url}/stet/account",
            token
        )
        if response.status_code == 200:
            return Accounts(accounts=response.json())
        else:
            return ErrorResponse(**response.json())

    def get_account(
            self,
            token: Token,
            account: Account
    ) -> Union[Account, ErrorResponse]:
        """Return the details of a single account linked
        to an account id of a user
        """
        response = self._get_request(
            f"{self.base_url}/stet/account/{account.id}",
            token
        )
        if response.status_code == 200:
            return Account(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_balances(
            self,
            token: Token,
            account: Account
    ) -> Union[Balances, ErrorResponse]:
        """Return the balances of a single account linked
        to a user
        """
        response = self._get_request(
            f"{self.base_url}/stet/account/{account.id}/balance",
            token
        )
        if response.status_code == 200:
            return Balances(balances=response.json())
        else:
            return ErrorResponse(**response.json())

    def get_transactions(
            self,
            token: Token,
            account: Account,
            page: int = 1
    ) -> Union[Transactions, ErrorResponse]:
        """Return the transactions of a single account linked
        to a user
        """
        response = self._get_request(
            f"{self.base_url}/stet/account/{account.id}/transaction",
            token,
            params={
                "page": page,
                "count": 100
            }
        )
        if response.status_code == 200:
            return Transactions(transactions=response.json())
        else:
            return ErrorResponse(**response.json())
