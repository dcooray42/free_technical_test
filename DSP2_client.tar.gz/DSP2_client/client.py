import httpx
from DSP2_client.models import (
    Account,
    Accounts,
    Balances,
    ClientConfig,
    ErrorResponse,
    Identity,
    Token
)
from typing import Union


class Client:
    def __init__(self, config: ClientConfig):
        self.base_url = str(config.base_url).rstrip("/")
        self.username = config.username
        self.password = config.password

    def authentication(self) -> Union[Token, ErrorResponse]:
        """Method to return the token of a valid user"""
        response = httpx.post(
            f"{self.base_url}/oauth/token",
            data={
                "username": self.username,
                "password": self.password,
                "scope": "stet"
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        if response.status_code == 200:
            return Token(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_identity(self, token: Token) -> Union[Identity, ErrorResponse]:
        """Method to return the identity of the user"""
        response = httpx.get(
            f"{self.base_url}/stet/identity",
            headers={
                "Authorization": f"Bearer {token.access_token}",
                "Accept": "application/json"
            }
        )
        if response.status_code == 200:
            return Identity(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_accounts(self, token: Token) -> Union[Accounts, ErrorResponse]:
        """Method to return all the accounts linked to a user"""
        response = httpx.get(
            f"{self.base_url}/stet/account",
            headers={
                "Authorization": f"Bearer {token.access_token}",
                "Accept": "application/json"
            }
        )
        if response.status_code == 200:
            return Accounts(accounts=response.json())
        else:
            return ErrorResponse(**response.json())

    def get_account(
            self,
            token: Token,
            account: Account
    ) -> Union[Account, ErrorResponse]:
        """Method to return the details of a single account linked
        to an account id of a user
        """
        response = httpx.get(
            f"{self.base_url}/stet/account/{account.id}",
            headers={
                "Authorization": f"Bearer {token.access_token}",
                "Accept": "application/json"
            }
        )
        if response.status_code == 200:
            return Account(**response.json())
        else:
            return ErrorResponse(**response.json())

    def get_balances(
            self,
            token: Token,
            account: Account
    ) -> Union[Account, ErrorResponse]:
        """Method to return the details of a single account linked
        to a user
        """
        response = httpx.get(
            f"{self.base_url}/stet/account/{account.id}/balance",
            headers={
                "Authorization": f"Bearer {token.access_token}",
                "Accept": "application/json"
            }
        )
        if response.status_code == 200:
            return Balances(balances=response.json())
        else:
            return ErrorResponse(**response.json())
