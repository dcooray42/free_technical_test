import httpx
from DSP2_client.models import ClientConfig, ErrorResponse, Identity, Token 
from typing import Union


class Client:
    def __init__(self, config: ClientConfig):
        self.base_url = str(config.base_url).rstrip("/")
        self.username = config.username
        self.password = config.password

    def authentication(self) -> int:
        response = httpx.post(
            f"{self.base_url}/oauth/token",
            data={
                "username":self.username,
                "password":self.password
            },
            headers={"Content-Type":"application/x-www-form-urlencoded"}
        )
        status_code = response.status_code
        if status_code == 200:
            return Token(**response.json())
        else:
            return ErrorResponse(**response.json())
