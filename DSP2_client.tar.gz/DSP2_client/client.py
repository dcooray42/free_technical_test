import httpx
from DSP2_client.models import ClientConfig, Token, ErrorResponse
from typing import Union


class Client:
    def __init__(self, config: ClientConfig):
        self.base_url = str(config.base_url).rstrip("/")
        self.username = config.username
        self.password = config.password
        self.auth: Union[Token, ErrorResponse, None] = None

    def authentication(self) -> int:
        response = httpx.post(
            f"{self.base_url}/oauth/token",
            data={
                "username":self.username,
                "password":self.password
            },
            headers={"Content-Type":"application/x-www-form-urlencoded"}
        )
        status_code = response.status_code
        if status_code == 200:
            self.auth = Token(**response.json())
            return status_code
        else:
            self.auth = ErrorResponse(**response.json())
            return status_code
