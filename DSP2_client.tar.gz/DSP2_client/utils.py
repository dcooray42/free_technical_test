from DSP2_client import Client, ClientConfig, Token
from pydantic import HttpUrl


def create_client(
        base_url: HttpUrl,
        username: str,
        password: str
) -> Token:
    config = ClientConfig(
        base_url=base_url,
        username=username,
        password=password
    )
    return Client(config=config)
