from pydantic import Basemodel

class OAuth(Basemodel):
    username: str
    password: str

class Token(Basemodel):
    access_token: str
    token_type: str

class Identity(Basemodel):
    id: str
    prefix: str
    first_name: str
    last_name: str
    date_of_birth: str

class Account(Basemodel):
    id: str
    type: str
    usage: str
    iban: str
    name: str
    currency: str

class Balance(Basemodel):
    id: str
    name: str
    amount: int
    currency: str
    type: str

class Transaction(Basemodel):
    id: str
    label: str
    amount: int
    crdt_dbit_indicator: str
    status: str
    currency: str
    data_operation: str
    data_processed: str
