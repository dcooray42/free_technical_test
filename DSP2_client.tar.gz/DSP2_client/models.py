from pydantic import BaseModel, HttpUrl
from typing import List


class ClientConfig(BaseModel):
    base_url: HttpUrl
    username: str
    password: str


class OAuth(BaseModel):
    username: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


class ErrorResponse(BaseModel):
    detail: str


class Identity(BaseModel):
    id: str
    prefix: str
    first_name: str
    last_name: str
    date_of_birth: str


class Account(BaseModel):
    id: str
    type: str
    usage: str
    iban: str
    name: str
    currency: str


class Accounts(BaseModel):
    accounts: List[Account]


class Balance(BaseModel):
    id: str
    name: str
    amount: int
    currency: str
    type: str


class Balances(BaseModel):
    balances: List[Balance]


class Transaction(BaseModel):
    id: str
    label: str
    amount: int
    crdt_dbit_indicator: str
    status: str
    currency: str
    date_operation: str
    date_processed: str


class Transactions(BaseModel):
    transactions: List[Transaction]
