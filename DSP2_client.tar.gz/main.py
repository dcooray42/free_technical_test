import os
import pandas as pd
from dotenv import load_dotenv
from DSP2_client import (
    Accounts,
    Balances,
    Client,
    Identities,
    Token,
    Transactions,
    create_client
)
from typing import List, Dict, Tuple


def get_balances(
        client: Client,
        token: Token,
        accounts: List
) -> List:
    """Returns all the balances of all the accounts
    of a single user
    """
    balances = []
    for account in accounts:
        balances += client.get_balances(token, account).balances
    return balances


def get_transactions(
        client: Client,
        token: Token,
        accounts: List
) -> List:
    """Returns all the transactions of all the accounts
    of a single user.
    When the result of the querry doesn't reach 100 entities,
    if quits the current loop to loop onto the next account.
    """
    transactions = []
    for account in accounts:
        page = 1
        page_100_entities = True
        while page_100_entities:
            transactions += (
                tmp_trans := client.get_transactions(
                    token,
                    account,
                    page
                ).transactions
            )
            page += 1
            if len(tmp_trans) != 100:
                page_100_entities = False
    return transactions


def extract_data(
        client_token: List[Tuple[Client, Token]]
) -> Dict:
    """Returns all the data from all the users : identity,
    accounts, balances and transactions.
    it[0] corresponds to a user
    it[1] corresponds to a token linked to the same user
    tmp_acc stores the account of the current user
    """
    identities = []
    accounts = []
    balances = []
    transactions = []
    for it in client_token:
        identities += [it[0].get_identity(it[1])]
        accounts += (tmp_acc := it[0].get_accounts(it[1]).accounts)
        balances += get_balances(it[0], it[1], tmp_acc)
        transactions += get_transactions(it[0], it[1], tmp_acc)
    return {
        "identities": Identities(
            identities=identities
        ),
        "accounts": Accounts(
            accounts=accounts
        ),
        "balances": Balances(
            balances=balances
        ),
        "transactions": Transactions(
            transactions=transactions
        )
    }


def create_csv(
        path: str,
        name: str,
        data: List[Dict]
):
    """Creates a Pandas dataframe to convert the data
    into a .csv
    """
    df = pd.DataFrame(data)
    df.to_csv(f"{path}{name}.csv", index=False, sep=",")


def create_result(
        identities: Identities,
        accounts: Accounts,
        balances: Balances,
        transactions: Transactions,
        path: str = "./results/"
):
    """Passes all the data to the function "create_csv"
    to have a better structure and readibility
    """
    create_csv(
        path,
        "identities",
        [id.model_dump() for id in identities.identities]
    )
    create_csv(
        path,
        "accounts",
        [acc.model_dump() for acc in accounts.accounts]
    )
    create_csv(
        path,
        "balances",
        [bal.model_dump() for bal in balances.balances]
    )
    create_csv(
        path,
        "transactions",
        [trans.model_dump() for trans in transactions.transactions]
    )


def main():
    load_dotenv()
    client_one = create_client(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_1"),
        password=os.getenv("TEST_PASSWORD_1")
    )
    client_two = create_client(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_2"),
        password=os.getenv("TEST_PASSWORD_2")
    )
    token_one = client_one.authentication()
    token_two = client_two.authentication()
    data = extract_data(
        [
            (client_one, token_one),
            (client_two, token_two)
        ]
    )
    create_result(**data)


if __name__ == "__main__":
    main()
