import os
from dotenv import load_dotenv
from DSP2_client.client import Client
from DSP2_client.models import (
    Accounts,
    ClientConfig,
    Identity,
    Token
)


load_dotenv()


def test_get_identity_valid_token_one():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_1"),
        password=os.getenv("TEST_PASSWORD_1")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert isinstance((client.get_accounts(token, identity)), Accounts)


def test_get_identity_valid_token_two():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_2"),
        password=os.getenv("TEST_PASSWORD_2")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert isinstance((client.get_accounts(token, identity)), Accounts)
