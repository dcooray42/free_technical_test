from DSP2_client.models import (
    Account,
    Accounts,
    Balances,
    ErrorResponse,
    Identity,
    Token,
    Transactions
)
from DSP2_client.utils import create_client
from pydantic import HttpUrl
from typing import Union


def connection(
        base_url: HttpUrl,
        username: str,
        password: str,
        data_type: Union[Token, ErrorResponse]
):
    client = create_client(
        base_url,
        username,
        password
    )
    assert isinstance(client.authentication(), data_type)


def identity(
        base_url: HttpUrl,
        username: str,
        password: str,
        first_name: str = None,
        last_name: str = None
):
    client = create_client(
        base_url,
        username,
        password
    )
    if first_name and last_name:
        assert isinstance(token := client.authentication(), Token)
        assert isinstance((identity := client.get_identity(token)), Identity)
        assert identity.first_name == first_name
        assert identity.last_name == last_name
    else:
        assert isinstance(client.authentication(), ErrorResponse)
        token = Token(access_token="test", token_type="bearer")
        assert isinstance(client.get_identity(token), ErrorResponse)


def accounts(
        base_url: HttpUrl,
        username: str,
        password: str
):
    client = create_client(
        base_url,
        username,
        password
    )
    assert isinstance(token := client.authentication(), Token)
    assert isinstance(client.get_identity(token), Identity)
    assert isinstance((client.get_accounts(token)), Accounts)


def account(
        base_url: HttpUrl,
        username: str,
        password: str,
        false_account: bool = False
):
    client = create_client(
        base_url,
        username,
        password
    )
    assert isinstance(token := client.authentication(), Token)
    assert isinstance(client.get_identity(token), Identity)
    assert isinstance((accounts := client.get_accounts(token)), Accounts)
    if false_account is not False:
        for account in accounts.accounts:
            assert isinstance(
                (result := client.get_account(token, account)),
                Account
            )
            assert account.id == result.id
            assert account.type == result.type
            assert account.usage == result.usage
            assert account.iban == result.iban
            assert account.name == result.name
            assert account.currency == result.currency
    else:
        accounts.accounts[0].id = "test"  # Force the account to no exist
        assert isinstance(
            client.get_account(token, accounts.accounts[0]),
            ErrorResponse
        )


def balances(
        base_url: HttpUrl,
        username: str,
        password: str,
        false_account: bool = False
):
    client = create_client(
        base_url,
        username,
        password
    )
    assert isinstance(token := client.authentication(), Token)
    assert isinstance(client.get_identity(token), Identity)
    assert isinstance((accounts := client.get_accounts(token)), Accounts)
    if false_account is not False:
        for account in accounts.accounts:
            assert isinstance(
                client.get_balances(token, account),
                Balances
            )
    else:
        accounts.accounts[0].id = "test"  # Force the account to no exist
        assert isinstance(
            client.get_balances(token, accounts.accounts[0]),
            ErrorResponse
        )


def transactions(
        base_url: HttpUrl,
        username: str,
        password: str,
        false_account: bool = False
):
    client = create_client(
        base_url,
        username,
        password
    )
    assert isinstance(token := client.authentication(), Token)
    assert isinstance(client.get_identity(token), Identity)
    assert isinstance((accounts := client.get_accounts(token)), Accounts)
    if false_account is not False:
        for account in accounts.accounts:
            assert isinstance(
                client.get_transactions(token, account),
                Transactions
            )
    else:
        accounts.accounts[0].id = "test"  # Force the account to no exist
        assert isinstance(
            client.get_transactions(token, accounts.accounts[0]),
            ErrorResponse
        )
