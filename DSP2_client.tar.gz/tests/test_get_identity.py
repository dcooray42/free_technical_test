import os
from dotenv import load_dotenv
from DSP2_client.client import Client
from DSP2_client.models import ClientConfig, Identity, ErrorResponse, Token


load_dotenv()


def test_get_identity_valid_token_one():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_1"),
        password=os.getenv("TEST_PASSWORD_1")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert identity.first_name == "Maurice"
    assert identity.last_name == "Dupuis"


def test_get_identity_valid_token_two():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_2"),
        password=os.getenv("TEST_PASSWORD_2")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert identity.first_name == "Antoinette"
    assert identity.last_name == "Gribard"


def test_get_identity_invalid_token():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_3"),
        password=os.getenv("TEST_PASSWORD_3")
    )
    client = Client(config=config)
    assert isinstance(client.authentication(), ErrorResponse)
    token = Token(access_token="test", token_type="bearer")
    assert isinstance(client.get_identity(token), ErrorResponse)
