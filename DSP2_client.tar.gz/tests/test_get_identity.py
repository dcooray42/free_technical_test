import os
from dotenv import load_dotenv
from test_utils import identity


load_dotenv()


def test_get_identity_valid_token_one():
    """Test with the correct token given by the get_identity method
    for the first user
    """
    identity(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_1"),
        os.getenv("TEST_PASSWORD_1"),
        "Maurice",
        "Dupuis"
    )


def test_get_identity_valid_token_two():
    """Test with the correct token given by the get_identity method
    for the second user
    """
    identity(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2"),
        "Antoinette",
        "Gribard"
    )


def test_get_identity_invalid_token():
    """Test with a false token created by hand to check if the method
    will return an error
    """
    identity(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_3"),
        os.getenv("TEST_PASSWORD_3")
    )
