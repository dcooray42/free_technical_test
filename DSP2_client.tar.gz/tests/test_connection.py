import os
from dotenv import load_dotenv
from DSP2_client.models import ErrorResponse, Token
from test_utils import connection


load_dotenv()


def test_valid_connection_one():
    """Test with the credentials of the first user given in the subject"""
    connection(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_1"),
        os.getenv("TEST_PASSWORD_1"),
        Token
    )


def test_valid_connection_two():
    """Test with the credentials of the second user given in the subject"""
    connection(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2"),
        Token
    )


def test_false_credentials_connection():
    """Test with the credentials of a random user"""
    connection(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_3"),
        os.getenv("TEST_PASSWORD_3"),
        ErrorResponse
    )


def test_invalid_connection_one():
    """Test with the username of the first user and the
    password of the second user
    """
    connection(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_1"),
        os.getenv("TEST_PASSWORD_2"),
        ErrorResponse
    )


def test_invalid_connection_two():
    """Test with the username of the second user and the
    password of the first user
    """
    connection(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_1"),
        ErrorResponse
    )
