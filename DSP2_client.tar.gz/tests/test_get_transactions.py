import os
from dotenv import load_dotenv
from test_utils import transactions


load_dotenv()


def test_get_transactions_valid_token_one():
    """Test to check if the transactions of an account id are
    returned properly with the token of the first user
    """
    transactions(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_1"),
        os.getenv("TEST_PASSWORD_1")
    )


def test_get_transactions_valid_token_two():
    """Test to check if the transactions of an account id are
    returned properly with the token of the second user
    """
    transactions(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2")
    )


def test_get_transactions_invalid_account():
    """Test to check if we pass a false accound_id, the route will return
    an error
    """
    transactions(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2"),
        True
    )
