import os
from dotenv import load_dotenv
from DSP2_client.client import Client
from DSP2_client.models import (
    Account,
    Accounts,
    ClientConfig,
    ErrorResponse,
    Identity,
    Token
)


load_dotenv()


def test_get_account_valid_token_one():
    """Test to check if the accounts are returned with token of the first
    user
    """
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_1"),
        password=os.getenv("TEST_PASSWORD_1")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert isinstance(
        (accounts := client.get_accounts(token, identity)),
        Accounts
    )
    for account in accounts:
        assert isinstance(client.get_account(token, account), Account)


def test_get_account_valid_token_two():
    """Test to check if the accounts are returned with token of the second
    user
    """
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_2"),
        password=os.getenv("TEST_PASSWORD_2")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert isinstance(
        (accounts := client.get_accounts(token, identity)),
        Accounts
    )
    for account in accounts:
        assert isinstance(client.get_account(token, account), Account)


def test_get_account_invalid_account():
    config = ClientConfig(
        base_url=os.getenv("API_URL"),
        username=os.getenv("TEST_USER_2"),
        password=os.getenv("TEST_PASSWORD_2")
    )
    client = Client(config=config)
    assert isinstance(token := client.authentication(), Token)
    assert isinstance((identity := client.get_identity(token)), Identity)
    assert isinstance(
        (accounts := client.get_accounts(token, identity)),
        Accounts
    )
    accounts[0].id = "test"
    assert isinstance(client.getaccount(token, accounts[0]), ErrorResponse)
