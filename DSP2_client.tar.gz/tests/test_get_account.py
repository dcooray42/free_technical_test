import os
from dotenv import load_dotenv
from test_utils import account


load_dotenv()


def test_get_account_valid_token_one():
    """Test to check if the account id returns the same informations
    with this route with the token of the first user
    """
    account(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_1"),
        os.getenv("TEST_PASSWORD_1")
    )


def test_get_account_valid_token_two():
    """Test to check if the account id returns the same informations
    with this route with token of the second user
    """
    account(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2")
    )


def test_get_account_invalid_account():
    """Test to check if we pass a false accound_id, the route will return
    an error
    """
    account(
        os.getenv("API_URL"),
        os.getenv("TEST_USER_2"),
        os.getenv("TEST_PASSWORD_2"),
        True
    )
